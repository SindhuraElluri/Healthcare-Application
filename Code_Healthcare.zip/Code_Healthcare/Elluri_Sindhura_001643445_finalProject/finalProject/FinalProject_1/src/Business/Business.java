/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Doctor.DoctorDirectory;
import Business.Incident.IncidentDirectory;
import Business.Organization.OrganizationDirectory;
import Business.Patient.PatientRecordDirectory;
import Business.SurveillanceReport.SurveillanceReportDirectory;
import Business.VulnerabilityAssessment.VulnerabilityAssessmentDirectory;

/**
 *
 * @author Administrator
 */
public class Business
{

  private static Business business;
  private final OrganizationDirectory organizationDirectory;
  private final IncidentDirectory incidentDirectory;
  private final VulnerabilityAssessmentDirectory vulnerabilityAssessmentDirectory;
  private final PatientRecordDirectory patientRecordDirectory;
  private final DoctorDirectory doctorDirectory;
  private final SurveillanceReportDirectory surveillanceReportDirectory;

  public static Business getInstance()
  {
    if (business == null)
    {
      business = new Business();
    }
    return business;
  }

  private Business()
  {
    organizationDirectory = new OrganizationDirectory();
    incidentDirectory = new IncidentDirectory();
    vulnerabilityAssessmentDirectory = new VulnerabilityAssessmentDirectory();
    patientRecordDirectory = new PatientRecordDirectory();
    doctorDirectory = new DoctorDirectory();
    surveillanceReportDirectory = new SurveillanceReportDirectory();
  }

  public OrganizationDirectory getOrganizationDirectory()
  {
    return organizationDirectory;
  }

  public IncidentDirectory getIncidentDirectory()
  {
    return incidentDirectory;
  }

  public VulnerabilityAssessmentDirectory getVulnerabilityAssessmentDirectory()
  {
    return vulnerabilityAssessmentDirectory;
  }

  public PatientRecordDirectory getPatientRecordDirectory()
  {
    return patientRecordDirectory;
  }

  public DoctorDirectory getDoctorDirectory()
  {
    return doctorDirectory;
  }

  public SurveillanceReportDirectory getSurveillanceReportDirectory()
  {
    return surveillanceReportDirectory;
  }

}
