/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Employee;

/**
 *
 * @author Sindhura Elluri
 */
public class Employee implements Comparable<Employee>
{

  private String name;
  private Long id;
  private static Long count = 1L;

  public Employee()
  {
    id = count++;
  }

  public Long getId()
  {
    return id;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public String getName()
  {
    return name;
  }

  @Override
  public String toString()
  {
    return name;
  }

  @Override
  public int hashCode()
  {
    int hash = 3;
    hash = 29 * hash + (int) (this.id ^ (this.id >>> 32));
    return hash;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    final Employee other = (Employee) obj;
    if (this.id.equals(other.id))
    {
      return false;
    }
    return true;
  }

  @Override
  public int compareTo(Employee o)
  {
    return this.id.compareTo(o.id);
  }

}
