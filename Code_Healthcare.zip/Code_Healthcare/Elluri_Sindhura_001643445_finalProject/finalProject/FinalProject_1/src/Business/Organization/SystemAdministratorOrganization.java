//*************************************************//
//          //
//*************************************************//
package Business.Organization;

import Business.Role.Role;
import Business.Role.SystemAdministratorRole;
import java.util.ArrayList;

/**
 *
 * @since Apr 21, 2016
 * @author Sindhura Elluri
 */
public class SystemAdministratorOrganization extends Organization
{

  public SystemAdministratorOrganization()
  {
    super(Type.SystemAdministrator.getValue());
  }

  @Override
  public ArrayList<Role> getSupportedRole()
  {
    final ArrayList<Role> list = new ArrayList<>();
    list.add(new SystemAdministratorRole());
    return list;
  }

}
