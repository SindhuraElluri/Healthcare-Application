//*************************************************//
//          //
//*************************************************//
package Business.Patient;

import java.util.Date;

/**
 *
 * @since Apr 20, 2016
 * @author Sindhura Elluri
 */
public class VitalSigns
{

  public static final int HEARTH_RATE_MIN = 70;
  public static final int HEARTH_RATE_MAX = 90;
  public static final float TEMPERATURE_MIN = 96;
  public static final float TEMPERATURE_MAX = 98;
  public static final int RESPIRATORY_RATE_MIN = 120;
  public static final int RESPIRATORY_RATE_MAX = 150;
  public static final int BLOOD_PRESSURE_MIN = 70;
  public static final int BLOOD_PRESSURE_MAX = 120;

  private final PatientRecord patientRecord;
  private final int hearthRate;
  private final float temperature;
  private final int respiratoryRate;
  private final int bloodPressure;
  private final int weight;
  private final Date date;

  public VitalSigns(PatientRecord patientRecord, Date date, int hearthRate, float temperature, int respiratoryRate, int bloodPressure, int weight)
  {
    this.patientRecord = patientRecord;
    this.hearthRate = hearthRate;
    this.temperature = temperature;
    this.respiratoryRate = respiratoryRate;
    this.bloodPressure = bloodPressure;
    this.weight = weight;
    this.date = date;
  }

  public PatientRecord getPatientRecord()
  {
    return patientRecord;
  }

  public int getHearthRate()
  {
    return hearthRate;
  }

  public float getTemperature()
  {
    return temperature;
  }

  public int getRespiratoryRate()
  {
    return respiratoryRate;
  }

  public int getBloodPressure()
  {
    return bloodPressure;
  }

  public int getWeight()
  {
    return weight;
  }

  public Date getDate()
  {
    return date;
  }

}
