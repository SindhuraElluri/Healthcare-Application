//*************************************************//
//          //
//*************************************************//
package Business.Patient;

import Business.Doctor.Doctor;
import java.util.Collection;
import java.util.Date;

/**
 *
 * @since Apr 20, 2016
 * @author Sindhura Elluri
 */
public class DiagnosisSummary
{

  private final PatientRecord patientRecord;
  private final Doctor doctor;
  private final Ailement ailement;
  private final String observation;
  private final String medication;
  private final Date date;

  public DiagnosisSummary(PatientRecord patientRecord, Doctor doctor, Ailement ailement, String observation, String medication)
  {
    this.patientRecord = patientRecord;
    this.doctor = doctor;
    this.ailement = ailement;
    this.observation = observation;
    this.medication = medication;
    this.date = new Date();
  }

  public PatientRecord getPatientRecord()
  {
    return patientRecord;
  }

  public Doctor getDoctor()
  {
    return doctor;
  }

  public Ailement getAilement()
  {
    return ailement;
  }

  public String getObservation()
  {
    return observation;
  }

  public String getMedication()
  {
    return medication;
  }

  public Date getDate()
  {
    return date;
  }

  public enum Ailement
  {
    FEVER("Fever"),
    COLD("Cough/cold"),
    HEADACHE("Headache"),
    CHOLERA("Cholera"),
    TYPHOID("Typhoid"),
    FLU("Flu"),
    STOMACH_PAIN("Stomach Pain"),
    EYE_ISSUES("Eye sight issues"),
    DIABETES("Diabetes"),
    MALARIA("Malaria"),
    CARDIAC_AREST("Cardiac Arrest"),
    LEUKEMIA("Leukemia"),
    PSORIASIS("Psoriasis");
    private final String value;

    private Ailement(String value)
    {
      this.value = value;
    }

    public String getValue()
    {
      return value;
    }

    private static String[] stringValues()
    {
      final Ailement[] values = values();
      final String[] stringValues = new String[values.length];
      for (int i = 0; i < values.length; i++)
      {
        stringValues[i] = values[i].getValue();
      }
      return stringValues;
    }

    public static String[] stringValues(Collection<Ailement> ailements)
    {
      Ailement[] ails = ailements.toArray(new Ailement[ailements.size()]);
      final String[] stringValues = new String[ails.length];
      for (int i = 0; i < ails.length; i++)
      {
        stringValues[i] = ails[i].getValue();
      }
      return stringValues;
    }

    public static Ailement getEnum(String value)
    {
      for (Ailement ailement : values())
      {
        if (ailement.getValue().equals(value))
        {
          return ailement;
        }
      }
      return null;
    }
    public static String[] ailements = stringValues();
  }
}
