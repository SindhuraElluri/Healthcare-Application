//*************************************************//
//          //
//*************************************************//
package Business.Patient;

import Business.UserAccount.UserAccount;
import Business.WorkQueue.Test;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 *
 * @since Apr 20, 2016
 * @author Sindhura Elluri
 */
public class PatientRecord
{

  private boolean complete;
  private final UserAccount patient;
  private Gender gender;
  private Date dob;
  private BloodGroup bloodGroup;
  private Date date;
  private String address;
  private String phoneNumber;
  private String chronicCondition;
  private List<DiagnosisSummary> consultations = new ArrayList<>();
  private List<VitalSigns> vitalSignsList = new ArrayList<>();
  private List<Test> tests = new ArrayList<>();

  PatientRecord(UserAccount patient)
  {
    this.patient = patient;
  }

  public UserAccount getPatient()
  {
    return patient;
  }

  public Gender getGender()
  {
    return gender;
  }

  public void setGender(Gender gender)
  {
    this.gender = gender;
  }

  public Date getDob()
  {
    return dob;
  }

  public void setDob(Date dob)
  {
    this.dob = dob;
  }

  public BloodGroup getBloodGroup()
  {
    return bloodGroup;
  }

  public void setBloodGroup(BloodGroup bloodGroup)
  {
    this.bloodGroup = bloodGroup;
  }

  public Date getDate()
  {
    return date;
  }

  public void setDate(Date date)
  {
    this.date = date;
  }

  public String getName()
  {
    return patient.getEmployee().getName();
  }

  public void setName(String name)
  {
    patient.getEmployee().setName(name);
  }

  public String getAddress()
  {
    return address;
  }

  public void setAddress(String address)
  {
    this.address = address;
  }

  public String getPhoneNumber()
  {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber)
  {
    this.phoneNumber = phoneNumber;
  }

  public String getChronicCondition()
  {
    return chronicCondition;
  }

  public void setChronicCondition(String chronicCondition)
  {
    this.chronicCondition = chronicCondition;
  }

  public boolean isComplete()
  {
    return complete;
  }

  public void setComplete(boolean complete)
  {
    this.complete = complete;
  }

  public List<DiagnosisSummary> getConsultations()
  {
    return Collections.unmodifiableList(consultations);
  }

  void addConsultation(DiagnosisSummary summary)
  {
    consultations.add(summary);
  }

  public List<VitalSigns> getVitalSignsList()
  {
    return Collections.unmodifiableList(vitalSignsList);
  }

  void addVitalSigns(VitalSigns vitalSigns)
  {
    this.vitalSignsList.add(vitalSigns);
  }

  public List<Test> getTests()
  {
    return Collections.unmodifiableList(tests);
  }

  public void addTest(Test test)
  {
    tests.add(test);
  }

  @Override
  public int hashCode()
  {
    int hash = 7;
    hash = 11 * hash + Objects.hashCode(this.patient);
    return hash;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    final PatientRecord other = (PatientRecord) obj;
    if (!Objects.equals(this.patient, other.patient))
    {
      return false;
    }
    return true;
  }

  public enum Gender
  {
    M, F;

    private static String[] stringValues()
    {
      final Gender[] values = values();
      final String[] stringValues = new String[values.length];
      for (int i = 0; i < values.length; i++)
      {
        stringValues[i] = values[i].toString();
      }
      return stringValues;
    }
    public static String[] genders = stringValues();
  }

  public enum BloodGroup
  {
    O_P, O_N, A_P, A_N, B_P, B_N, AB_P, AB_N;

    @Override
    public String toString()
    {
      return super.toString().replace("_P", "+").replace("_N", "-");
    }

    public static BloodGroup getEnum(String string)
    {
      return valueOf(string.replace("+", "_P").replace("-", "_N"));
    }

    private static String[] stringValues()
    {
      final BloodGroup[] values = values();
      final String[] stringValues = new String[values.length];
      for (int i = 0; i < values.length; i++)
      {
        stringValues[i] = values[i].toString();
      }
      return stringValues;
    }
    public static String[] groups = stringValues();
  }

}
