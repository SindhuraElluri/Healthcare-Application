//*************************************************//
//          //
//*************************************************//
package Business.Patient;

import Business.Doctor.Doctor;
import Business.Patient.DiagnosisSummary.Ailement;
import Business.UserAccount.UserAccount;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @since Apr 20, 2016
 * @author Sindhura Elluri
 */
public class PatientRecordDirectory
{

  private final Map<UserAccount, PatientRecord> records = new TreeMap<>();

  public PatientRecord findOrCreateByUserAccount(UserAccount patientAccount)
  {
    PatientRecord record = records.get(patientAccount);
    if (record == null)
    {
      record = new PatientRecord(patientAccount);
      records.put(patientAccount, record);
    }
    return record;
  }

  public DiagnosisSummary addConsultation(PatientRecord record, Doctor doctor, Ailement ailement, String observation, String medication)
  {
    final DiagnosisSummary diagnosisSummary = new DiagnosisSummary(record, doctor, ailement, observation, medication);
    record.addConsultation(diagnosisSummary);
    return diagnosisSummary;
  }

  public VitalSigns addVitalSigns(PatientRecord record, Date date, int hearthRate, float temperature, int respiratoryRate, int bloodPresure, int weight)
  {
    final VitalSigns vitalSigns = new VitalSigns(record, date, hearthRate, temperature, respiratoryRate, bloodPresure, weight);
    record.addVitalSigns(vitalSigns);
    return vitalSigns;
  }

  public PatientRecord findById(Long id)
  {
    for (PatientRecord value : records.values())
    {
      if (value.getPatient().getEmployee().getId().equals(id))
      {
        return value;
      }
    }
    return null;
  }

  public Collection<PatientRecord> getAllRecords()
  {
    return Collections.unmodifiableCollection(records.values());
  }

  public String[] getAllIds()
  {
    String[] all = new String[records.values().size()];
    int i = 0;
    for (PatientRecord value : records.values())
    {
      all[i++] = value.getPatient().getEmployee().getId().toString();
    }
    return all;
  }

}
