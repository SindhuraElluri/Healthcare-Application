//*************************************************//
//          INTHER LOGISTICS ENGINEERING           //
//*************************************************//
package Business.Doctor;

import Business.Doctor.Doctor.Department;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @since Apr 20, 2016
 * @author Sindhura Elluri
 */
public class DoctorDirectory
{

  private List<Doctor> doctors = new ArrayList<>();

  public Doctor create(UserAccount account, Department department)
  {
    final Doctor doctor = new Doctor(account, department);
    doctors.add(doctor);
    return doctor;
  }

  public Doctor findById(Long id)
  {
    for (Doctor doctor : doctors)
    {
      if (doctor.getAccount().getEmployee().getId().equals(id))
      {
        return doctor;
      }
    }
    return null;
  }

  public Doctor findByAccount(UserAccount account)
  {
    for (Doctor doctor : doctors)
    {
      if (doctor.getAccount().equals(account))
      {
        return doctor;
      }
    }
    return null;

  }

  public List<Doctor> findByDepartment(Department department)
  {
    List<Doctor> byDepartment = new ArrayList<>();
    for (Doctor doctor : doctors)
    {
      if (doctor.getDepartment() == department)
      {
        byDepartment.add(doctor);
      }
    }
    return byDepartment;
  }

  public Set<Department> findActiveDepartments()
  {
    Set<Department> activeDepartments = new TreeSet<>();
    for (Doctor doctor : doctors)
    {
      activeDepartments.add(doctor.getDepartment());
    }
    return activeDepartments;
  }

  public String[] getAllIds()
  {
    String[] all = new String[doctors.size()];
    int i = 0;
    for (Doctor value : doctors)
    {
      all[i++] = value.getAccount().getEmployee().getId().toString();
    }
    return all;
  }

  public List<Doctor> getDoctors()
  {
    return Collections.unmodifiableList(doctors);
  }

}
