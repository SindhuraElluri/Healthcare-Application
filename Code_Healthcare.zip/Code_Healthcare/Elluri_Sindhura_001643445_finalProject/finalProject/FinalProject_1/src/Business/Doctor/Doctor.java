//*************************************************//
//          INTHER LOGISTICS ENGINEERING           //
//*************************************************//
package Business.Doctor;

import Business.UserAccount.UserAccount;
import java.util.Collection;

/**
 *
 * @since Apr 20, 2016
 * @author Sindhura Elluri
 */
public class Doctor
{

  private final UserAccount account;
  private Department department;

  public Doctor(UserAccount account, Department department)
  {
    this.account = account;
    this.department = department;
  }

  public UserAccount getAccount()
  {
    return account;
  }

  public Department getDepartment()
  {
    return department;
  }

  public void setDepartment(Department department)
  {
    this.department = department;
  }

  public enum Department
  {
    CARDIOLOGY("Cardiology"),
    GENERAL_PHYSICIAN("General Physician"),
    PEDIATRICIAN("Pediatrician"),
    GYNECOLOGIST("Gynecologist"),
    NEUROLOGIST("Neurologist"),
    ONCOLOGIST("Oncologist"),
    PSYCHIATRIST("Psychiatrist");
    private final String value;

    private Department(String value)
    {
      this.value = value;
    }

    public String getValue()
    {
      return value;
    }

    private static String[] stringValues()
    {
      final Department[] values = values();
      final String[] stringValues = new String[values.length];
      for (int i = 0; i < values.length; i++)
      {
        stringValues[i] = values[i].getValue();
      }
      return stringValues;
    }

    public static String[] stringValues(Collection<Department> departments)
    {
      Department[] deps = departments.toArray(new Department[departments.size()]);
      final String[] stringValues = new String[deps.length];
      for (int i = 0; i < deps.length; i++)
      {
        stringValues[i] = deps[i].getValue();
      }
      return stringValues;
    }

    public static Department getEnum(String value)
    {
      for (Department dep : values())
      {
        if (dep.getValue().equals(value))
        {
          return dep;
        }
      }
      return null;
    }
    public static String[] departments = stringValues();

  }
}
