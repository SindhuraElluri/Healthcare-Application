/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Incident;

import Business.UserAccount.UserAccount;
import Business.WorkQueue.CostAnalysisRequest;
import java.awt.Color;
import static java.awt.Color.BLACK;
import static java.awt.Color.BLUE;
import static java.awt.Color.GREEN;
import static java.awt.Color.MAGENTA;
import static java.awt.Color.ORANGE;
import static java.awt.Color.RED;
import static java.awt.Color.YELLOW;

/**
 *
 * @author Sindhura Elluri
 */
public abstract class Incident
{

  private static long count = 0;
  private final long id = count++;
  private Severity severity;
  private Status status;
  private UserAccount incidentManager;
  private String notes;
  private final CostAnalysisRequest costAnalysis = new CostAnalysisRequest(this);

  public Incident(Severity severity)
  {
    this(severity, null);
  }

  public Incident(Severity severity, UserAccount incidentManager)
  {
    this.status = incidentManager == null ? Status.UNASSIGNED : Status.ASSIGNED;
    this.severity = severity;
    this.incidentManager = incidentManager;
  }

  public void setIncidentManager(UserAccount incidentManager)
  {
    this.incidentManager = incidentManager;
  }

  public Long getId()
  {
    return id;
  }

  public String getNotes()
  {
    return notes;
  }

  public void setNotes(String notes)
  {
    this.notes = notes;
  }

  public void setSeverity(Severity severity)
  {
    this.severity = severity;
  }

  public Status getStatus()
  {
    return status;
  }

  public Severity getSeverity()
  {
    return severity;
  }

  public UserAccount getIncidentManager()
  {
    return incidentManager;
  }

  public void setStatus(Status status)
  {
    this.status = status;
  }

  public CostAnalysisRequest getCostAnalysis()
  {
    return costAnalysis;
  }

  public abstract String message();

  public enum Severity
  {
    HIGH(RED), MEDIUM(YELLOW), LOW(MAGENTA);
    private final Color color;

    private Severity(Color color)
    {
      this.color = color;
    }

    public Color getColor()
    {
      return color;
    }

    public static String[] stringValues()
    {
      String[] val = new String[values().length];
      for (int i = 0; i < val.length; i++)
      {
        val[i] = values()[i].toString();
      }
      return val;
    }
  }

  public enum Status
  {
    UNASSIGNED(BLACK), ASSIGNED(ORANGE), IN_PROGRESS(BLUE), RESOLVED(GREEN);
    private final Color color;

    private Status(Color color)
    {
      this.color = color;
    }

    public Color getColor()
    {
      return color;
    }

    public static String[] stringValues()
    {
      String[] val = new String[values().length];
      for (int i = 0; i < val.length; i++)
      {
        val[i] = values()[i].toString();
      }
      return val;
    }
  }
}
