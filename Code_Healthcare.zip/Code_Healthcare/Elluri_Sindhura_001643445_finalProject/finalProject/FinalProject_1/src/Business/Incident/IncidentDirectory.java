/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Incident;

import Business.Incident.Incident.Severity;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sindhura Elluri
 */
public class IncidentDirectory {

    private final List<Incident> incidentList = new ArrayList<>();

    public List<Incident> getIncidentList() {
        return incidentList;
    }

    public Incident createSecurityIncident(UserAccount failedLoginAccount, String expectedAddress, String actualAddress) {
        final SecurityIncident incident = new SecurityIncident(failedLoginAccount, expectedAddress, actualAddress, Incident.Severity.LOW);
        incidentList.add(incident);
        return incident;
    }

    public Incident createGenericIncident(String description, Severity severity) {
        final GenericIncident incident = new GenericIncident(description, severity);
        incidentList.add(incident);
        return incident;
    }

    public Incident createGenericIncident(String description, Severity severity, UserAccount incidentManager) {
        final GenericIncident incident = new GenericIncident(description, severity, incidentManager);
        incidentList.add(incident);
        return incident;
    }

    public Incident findById(Long id) {
        for (Incident incident : incidentList) {
            if (incident.getId().equals(id)) {
                return incident;
            }
        }
        return null;
    }
}
