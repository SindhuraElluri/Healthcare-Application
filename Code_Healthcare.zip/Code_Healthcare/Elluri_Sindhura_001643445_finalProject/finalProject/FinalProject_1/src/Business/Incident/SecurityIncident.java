/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Incident;

import Business.UserAccount.UserAccount;

/**
 *
 * @author Sindhura Elluri
 */
public class SecurityIncident extends Incident {

    private final UserAccount failedLoginAccount;
    private final String expectedAddress;
    private final String actualAddress;

    public SecurityIncident(UserAccount failedLoginAccount, String expectedAddress, String actualAddress, Severity severity) {
        super(severity);
        this.failedLoginAccount = failedLoginAccount;
        this.expectedAddress = expectedAddress;
        this.actualAddress = actualAddress;
    }

    @Override
    public String message() {
        return String.format("user[%s] tried to login from address[%s], expected address[%s].",
                failedLoginAccount.getUsername(), actualAddress, expectedAddress);
    }

}
