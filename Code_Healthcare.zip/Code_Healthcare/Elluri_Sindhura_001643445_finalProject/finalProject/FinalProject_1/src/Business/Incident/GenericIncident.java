/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Incident;

import Business.UserAccount.UserAccount;

/**
 *
 * @author Sindhura Elluri
 */
public class GenericIncident extends Incident {

    private final String message;

    public GenericIncident(String message, Severity severity) {
        super(severity);
        this.message = message;
    }

    public GenericIncident(String message, Severity severity, UserAccount incidentManager) {
        super(severity, incidentManager);
        this.message = message;
    }

    @Override
    public String message() {
        return message;
    }

}
