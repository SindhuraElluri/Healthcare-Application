/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Incident;

import Business.UserAccount.UserAccount;
import java.util.Date;

/**
 *
 * @author Sindhura Elluri
 */
public class SecurityIncidentException extends Exception {

    private final UserAccount account;
    private final String expectedAddress;
    private final String actualAddress;

    public SecurityIncidentException(UserAccount account, String expectedAddress, String actualAddress) {
        this.account = account;
        this.expectedAddress = expectedAddress;
        this.actualAddress = actualAddress;
    }

    public UserAccount getAccount() {
        return account;
    }

    public String getExpectedAddress() {
        return expectedAddress;
    }

    public String getActualAddress() {
        return actualAddress;
    }

}
