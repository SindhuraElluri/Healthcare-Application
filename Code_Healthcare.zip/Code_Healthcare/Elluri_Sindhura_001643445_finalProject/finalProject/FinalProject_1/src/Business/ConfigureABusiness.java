/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Doctor.Doctor.Department;
import Business.Employee.Employee;
import Business.Incident.Incident.Severity;
import Business.Organization.AdminOrganization;
import Business.Organization.DoctorOrganization;
import Business.Organization.IncidentManagerOrganization;
import Business.Organization.LabOrganization;
import Business.Organization.MassSurveillanceAdminOrganization;
import Business.Organization.Organization;
import Business.Organization.PatientOrganization;
import Business.Organization.SecurityAdministratorOrganization;
import Business.Organization.SystemAdministratorOrganization;
import Business.Patient.PatientRecord;
import Business.Patient.PatientRecord.BloodGroup;
import Business.Patient.PatientRecord.Gender;
import Business.Patient.VitalSigns;
import Business.Role.AdminRole;
import Business.Role.DoctorRole;
import Business.Role.IncidentManagerRole;
import Business.Role.LabAssistantRole;
import Business.Role.MassSurveillanceAdminRole;
import Business.Role.PatientRole;
import Business.Role.SecurityAdministratorRole;
import Business.Role.SystemAdministratorRole;
import Business.UserAccount.UserAccount;
import Business.VulnerabilityAssessment.VulnerabilityAssessment.Range;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

/**
 *
 * @author Sindhura Elluri
 */
public class ConfigureABusiness
{

  public static Business configure()
  {

    Business business = Business.getInstance();

    configureAdminOrganization(business);
    configureSecurityAdministratorOrganization(business);
    configurePatientOrganization(business);
    configureDoctorOrganization(business);
    configureIncidentManagerOrganization(business);
    configureLabOrganization(business);
    configureSystemAdministratorOrganization(business);
    configureSurvOrganization(business);
    return business;
  }

  private static void configureAdminOrganization(Business business)
  {
    AdminOrganization adminOrganization = new AdminOrganization();
    business.getOrganizationDirectory().getOrganizationList().add(adminOrganization);

    Employee employee = new Employee();
    employee.setName("Raunak Agarwal");

    UserAccount account = new UserAccount();
    account.setUsername("admin");
    account.setPassword("admin");
    account.setRole(new AdminRole());
    account.setEmployee(employee);

    adminOrganization.getEmployeeDirectory().getEmployeeList().add(employee);
    adminOrganization.getUserAccountDirectory().getUserAccountList().add(account);
  }

  private static void configureSurvOrganization(Business business)
  {
    MassSurveillanceAdminOrganization adminOrganization = new MassSurveillanceAdminOrganization();
    business.getOrganizationDirectory().getOrganizationList().add(adminOrganization);

    Employee employee = new Employee();
    employee.setName("Mr Mass Surv");

    UserAccount account = new UserAccount();
    account.setUsername("surv");
    account.setPassword("surv");
    account.setRole(new MassSurveillanceAdminRole());
    account.setEmployee(employee);

    adminOrganization.getEmployeeDirectory().getEmployeeList().add(employee);
    adminOrganization.getUserAccountDirectory().getUserAccountList().add(account);
  }

  private static void configureSystemAdministratorOrganization(Business business)
  {
    SystemAdministratorOrganization adminOrganization = new SystemAdministratorOrganization();
    business.getOrganizationDirectory().getOrganizationList().add(adminOrganization);

    Employee employee = new Employee();
    employee.setName("Mr Sys Adm");

    UserAccount account = new UserAccount();
    account.setUsername("sadmin");
    account.setPassword("sadmin");
    account.setRole(new SystemAdministratorRole());
    account.setEmployee(employee);

    adminOrganization.getEmployeeDirectory().getEmployeeList().add(employee);
    adminOrganization.getUserAccountDirectory().getUserAccountList().add(account);
  }

  private static void configureSecurityAdministratorOrganization(Business business)
  {
    SecurityAdministratorOrganization org = new SecurityAdministratorOrganization();
    business.getOrganizationDirectory().getOrganizationList().add(org);
    final Employee employee = new Employee();
    employee.setName("Sec Adm");

    UserAccount account = new UserAccount();
    account.setUsername("secadm");
    account.setPassword("secadm");
    account.setRole(new SecurityAdministratorRole());
    account.setEmployee(employee);
    business.getIncidentDirectory().createGenericIncident("123", Severity.MEDIUM);
    business.getIncidentDirectory().createGenericIncident("1234", Severity.MEDIUM);
    business.getIncidentDirectory().createGenericIncident("1235", Severity.MEDIUM);
    business.getIncidentDirectory().createGenericIncident("1223123", Severity.HIGH);
    final Calendar cal = Calendar.getInstance();
    business.getVulnerabilityAssessmentDirectory().create(Range.R0_10, Range.R10_20, Range.R20_30, Range.R30_40, cal.getTime());
    cal.roll(Calendar.DAY_OF_MONTH, 1);
    business.getVulnerabilityAssessmentDirectory().create(Range.R40_50, Range.R80_90, Range.R40_50, Range.R50_60, cal.getTime());
    cal.roll(Calendar.DAY_OF_MONTH, 1);
    business.getVulnerabilityAssessmentDirectory().create(Range.R80_90, Range.R10_20, Range.R20_30, Range.R30_40, cal.getTime());
    cal.roll(Calendar.DAY_OF_MONTH, 1);
    business.getVulnerabilityAssessmentDirectory().create(Range.R0_10, Range.R10_20, Range.R20_30, Range.R30_40, cal.getTime());
    cal.roll(Calendar.DAY_OF_MONTH, 1);
    business.getVulnerabilityAssessmentDirectory().create(Range.R20_30, Range.R10_20, Range.R20_30, Range.R0_10, cal.getTime());
    cal.roll(Calendar.DAY_OF_MONTH, 1);
    business.getVulnerabilityAssessmentDirectory().create(Range.R0_10, Range.R40_50, Range.R20_30, Range.R10_20, cal.getTime());
    cal.roll(Calendar.DAY_OF_MONTH, 1);
    business.getVulnerabilityAssessmentDirectory().create(Range.R40_50, Range.R10_20, Range.R20_30, Range.R30_40, cal.getTime());
    org.getEmployeeDirectory().getEmployeeList().add(employee);
    org.getUserAccountDirectory().getUserAccountList().add(account);
  }

  private static void configureLabOrganization(Business business)
  {
    LabOrganization org = new LabOrganization();
    business.getOrganizationDirectory().getOrganizationList().add(org);
    final Employee employee = new Employee();
    employee.setName("Mr Lab");

    UserAccount account = new UserAccount();
    account.setUsername("lab");
    account.setPassword("lab");
    account.setRole(new LabAssistantRole());
    account.setEmployee(employee);
    org.getEmployeeDirectory().getEmployeeList().add(employee);
    org.getUserAccountDirectory().getUserAccountList().add(account);
  }

  private static void configureIncidentManagerOrganization(Business business)
  {
    IncidentManagerOrganization org = new IncidentManagerOrganization();
    business.getOrganizationDirectory().getOrganizationList().add(org);
    final Employee employee = new Employee();
    employee.setName("Inc Man");

    UserAccount account = new UserAccount();
    account.setUsername("incman");
    account.setPassword("incman");
    account.setRole(new IncidentManagerRole());
    account.setEmployee(employee);
    business.getIncidentDirectory().createGenericIncident("123", Severity.MEDIUM);
    business.getIncidentDirectory().createGenericIncident("1234", Severity.MEDIUM);
    business.getIncidentDirectory().createGenericIncident("1235", Severity.MEDIUM);
    business.getIncidentDirectory().createGenericIncident("1223123", Severity.HIGH);
    org.getEmployeeDirectory().getEmployeeList().add(employee);
    org.getUserAccountDirectory().getUserAccountList().add(account);
  }

  private static void configurePatientOrganization(Business business)
  {
    PatientOrganization org = new PatientOrganization();
    business.getOrganizationDirectory().getOrganizationList().add(org);

    createPatientAccount(business, org, "Mr Patient1", "pat1", "very bad condition");
    createPatientAccount(business, org, "Mr Patient2", "pat2", "very bad condition");
    createPatientAccount(business, org, "Mr Patient3", "pat3", "very bad condition");
    createPatientAccount(business, org, "Mr Patient4", "pat4", "very bad condition indeed");
    createPatientAccount(business, org, "Mr Patient5", "pat5", "very bad condition indeed");
    createPatientAccount(business, org, "Mr Patient6", "pat6", "very bad condition indeed");
  }

  private static UserAccount createPatientAccount(Business business, Organization org, String name, String username, String cond)
  {

    final Employee employee = new Employee();
    employee.setName(name);
    UserAccount account = new UserAccount();
    account.setUsername(username);
    account.setPassword(username);
    account.setRole(new PatientRole());
    account.setEmployee(employee);

    org.getEmployeeDirectory().getEmployeeList().add(employee);
    org.getUserAccountDirectory().getUserAccountList().add(account);
    createRecord(business, account, cond);
    return account;
  }

  private static void createRecord(Business business, UserAccount account, String cond)
  {
    final PatientRecord record = business.getPatientRecordDirectory().findOrCreateByUserAccount(account);
    record.setAddress("pat address");
    record.setBloodGroup(BloodGroup.AB_N);
    record.setChronicCondition(cond);
    record.setDate(new Date());
    final Calendar cal = Calendar.getInstance();
    cal.roll(Calendar.YEAR, 30);
    record.setDob(cal.getTime());
    record.setGender(Gender.M);
    record.setPhoneNumber("9009009000");
    record.setComplete(true);
    final Calendar vitalSignsCal = Calendar.getInstance();

    addVitalSigns(business, record, vitalSignsCal.getTime());
    vitalSignsCal.roll(Calendar.DAY_OF_MONTH, 1);
    addVitalSigns(business, record, vitalSignsCal.getTime());
    vitalSignsCal.roll(Calendar.DAY_OF_MONTH, 1);
    addVitalSigns(business, record, vitalSignsCal.getTime());
    vitalSignsCal.roll(Calendar.DAY_OF_MONTH, 1);
    addVitalSigns(business, record, vitalSignsCal.getTime());
    vitalSignsCal.roll(Calendar.DAY_OF_MONTH, 1);
    addVitalSigns(business, record, vitalSignsCal.getTime());
    vitalSignsCal.roll(Calendar.DAY_OF_MONTH, 1);
    addVitalSigns(business, record, vitalSignsCal.getTime());
    vitalSignsCal.roll(Calendar.DAY_OF_MONTH, 1);
    addVitalSigns(business, record, vitalSignsCal.getTime());
  }

  private static void addVitalSigns(Business business, final PatientRecord record, Date date)
  {
    Random r = new Random();
    int hr = r.nextInt(VitalSigns.HEARTH_RATE_MAX + 10 - VitalSigns.HEARTH_RATE_MIN - 10 + 1) + VitalSigns.HEARTH_RATE_MIN - 10;
    int bp = r.nextInt(VitalSigns.BLOOD_PRESSURE_MAX + 10 - VitalSigns.BLOOD_PRESSURE_MIN - 10 + 1) + VitalSigns.BLOOD_PRESSURE_MIN - 10;
    int rr = r.nextInt(VitalSigns.RESPIRATORY_RATE_MAX + 10 - VitalSigns.RESPIRATORY_RATE_MIN - 10 + 1) + VitalSigns.RESPIRATORY_RATE_MIN - 10;
    float temp = r.nextInt((int) VitalSigns.TEMPERATURE_MAX + 10 - (int) VitalSigns.TEMPERATURE_MIN - 10 + 1) + VitalSigns.TEMPERATURE_MIN - 10;
    int weight = r.nextInt((int) 400 + 10 - (int) 15 - 10 + 1) + 15 - 10;
    business.getPatientRecordDirectory().addVitalSigns(record, date, hr, temp, rr, bp, weight);
  }

  private static void configureDoctorOrganization(Business business)
  {
    DoctorOrganization org = new DoctorOrganization();
    business.getOrganizationDirectory().getOrganizationList().add(org);
    createDoctor("Dr. Brialy", "brialy", org, business, Department.CARDIOLOGY);
    createDoctor("Dr. Henry Wentworth", "hwentworth", org, business, Department.CARDIOLOGY);
    createDoctor("Dr. Anand Kumar", "akumar", org, business, Department.GENERAL_PHYSICIAN);
    createDoctor("Dr. Paul", "paul", org, business, Department.GENERAL_PHYSICIAN);
    createDoctor("Dr. Amy Jefferson", "ajefferson", org, business, Department.PEDIATRICIAN);
    createDoctor("Dr. George", "george", org, business, Department.PEDIATRICIAN);
    createDoctor("Dr. Whitteny Mark", "wmark", org, business, Department.GYNECOLOGIST);
    createDoctor("Dr. Rosallin", "rosallin", org, business, Department.GYNECOLOGIST);
    createDoctor("Dr. Ben", "ben", org, business, Department.NEUROLOGIST);
    createDoctor("Dr. Ted Eriksen", "teriksen", org, business, Department.NEUROLOGIST);
    createDoctor("Dr. Rebecca", "rebecca", org, business, Department.ONCOLOGIST);
    createDoctor("Dr. O’Brialy", "obrialy", org, business, Department.PSYCHIATRIST);
  }

  private static void createDoctor(String name, String userName, DoctorOrganization org, Business business, Department dep)
  {
    final Employee employee = new Employee();
    employee.setName(name);
    UserAccount account = new UserAccount();
    account.setUsername(userName);
    account.setPassword(userName);
    account.setRole(new DoctorRole());
    account.setEmployee(employee);
    org.getEmployeeDirectory().getEmployeeList().add(employee);
    org.getUserAccountDirectory().getUserAccountList().add(account);
    business.getDoctorDirectory().create(account, dep);
  }

}
