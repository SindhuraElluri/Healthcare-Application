//*************************************************//
//          //
//*************************************************//
package Business.Role;

import Business.Business;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import UserInterface.SystemAdministrator.SystemAdministratorWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @since Apr 21, 2016
 * @author Sindhura Elluri
 */
public class SystemAdministratorRole extends Role
{

  @Override
  public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Business business)
  {
    return new SystemAdministratorWorkAreaJPanel(userProcessContainer, business, account, organization);
  }

}
