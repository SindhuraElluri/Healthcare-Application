//*************************************************//
//          //
//*************************************************//
package Business.SurveillanceReport;

import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @since Apr 21, 2016
 * @author Sindhura Elluri
 */
public class SurveillanceReportDirectory
{

  private Map<Date, String> reports = new TreeMap<>(new Comparator<Date>()
  {
    @Override
    public int compare(Date o1, Date o2)
    {
      Calendar cal1 = Calendar.getInstance();
      Calendar cal2 = Calendar.getInstance();
      cal1.setTime(o1);
      cal2.setTime(o2);
      int compare = cal1.get(Calendar.YEAR) - cal2.get(Calendar.YEAR);
      if (compare != 0)
      {
        return compare;
      }
      return cal1.get(Calendar.DAY_OF_YEAR) - cal2.get(Calendar.DAY_OF_YEAR);
    }
  });

  public Map<Date, String> getAssessments()
  {
    return reports;
  }

  public String create(String report, Date date)
  {
    reports.put(date, report);
    return report;
  }

  public String findByDate(Date date)
  {
    return reports.get(date);
  }
}
