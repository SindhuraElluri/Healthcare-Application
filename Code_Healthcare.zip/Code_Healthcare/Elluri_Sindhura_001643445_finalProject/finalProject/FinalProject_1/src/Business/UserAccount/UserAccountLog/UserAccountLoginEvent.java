/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UserAccount.UserAccountLog;

import Business.UserAccount.UserAccount;

/**
 *
 * @author Sindhura Elluri
 */
public class UserAccountLoginEvent extends UserAccountEvent {

    public UserAccountLoginEvent(UserAccount userAccount, String address) {
        super(userAccount, address);
    }

}
