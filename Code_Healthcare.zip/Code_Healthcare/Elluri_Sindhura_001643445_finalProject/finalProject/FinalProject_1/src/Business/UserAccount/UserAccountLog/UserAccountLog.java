/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UserAccount.UserAccountLog;

import Business.UserAccount.UserAccount;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sindhura Elluri
 */
public class UserAccountLog {

    private final UserAccount account;
    private final List<UserAccountEvent> events = new ArrayList<>();

    public UserAccountLog(UserAccount account) {
        this.account = account;
    }

    public List<UserAccountEvent> getEvents() {
        return events;
    }

    public String getLastLoginAddress() {
        for (int i = events.size() - 1; i >= 0; i--) {
            final UserAccountEvent event = events.get(i);
            if (event instanceof UserAccountLoginEvent) {
                return event.getAddress();
            }

        }
        return null;
    }

    public UserAccountLoginEvent createUserAccountLoginEvent(String address) {
        final UserAccountLoginEvent event = new UserAccountLoginEvent(account, address);
        events.add(event);
        return event;
    }
}
