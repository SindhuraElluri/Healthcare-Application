/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UserAccount.UserAccountLog;

import Business.UserAccount.UserAccount;
import java.util.Date;

/**
 *
 * @author Sindhura Elluri
 */
public abstract class UserAccountEvent {

    private static Long count = 0L;
    private final Long id = count++;
    private final UserAccount userAccount;
    private final String address;
    private final Date timestamp;

    public UserAccountEvent(UserAccount userAccount, String address) {
        this.userAccount = userAccount;
        this.address = address;
        this.timestamp = new Date();
    }

    public UserAccount getUserAccount() {
        return userAccount;
    }

    public String getAddress() {
        return address;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public Long getId() {
        return id;
    }
}
