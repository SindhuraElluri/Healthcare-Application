/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UserAccount;

import Business.Employee.Employee;
import Business.Role.Role;
import Business.UserAccount.UserAccountLog.UserAccountLog;
import Business.WorkQueue.WorkQueue;
import java.util.Objects;

/**
 *
 * @author Sindhura Elluri
 */
public class UserAccount implements Comparable<UserAccount>
{

  private String username;
  private String password;
  private Employee employee;
  private Role role;
  private final WorkQueue workQueue;
  private final UserAccountLog userAccountLog;

  public UserAccount()
  {
    workQueue = new WorkQueue();
    userAccountLog = new UserAccountLog(this);
  }

  public String getUsername()
  {
    return username;
  }

  public void setUsername(String username)
  {
    this.username = username;
  }

  public String getPassword()
  {
    return password;
  }

  public void setPassword(String password)
  {
    this.password = password;
  }

  public Role getRole()
  {
    return role;
  }

  public void setEmployee(Employee employee)
  {
    this.employee = employee;
  }

  public void setRole(Role role)
  {
    this.role = role;
  }

  public Employee getEmployee()
  {
    return employee;
  }

  public WorkQueue getWorkQueue()
  {
    return workQueue;
  }

  public UserAccountLog getUserAccountLog()
  {
    return userAccountLog;
  }

  @Override
  public String toString()
  {
    return username;
  }

  @Override
  public int hashCode()
  {
    int hash = 7;
    hash = 31 * hash + Objects.hashCode(this.employee);
    return hash;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    final UserAccount other = (UserAccount) obj;
    if (!Objects.equals(this.employee, other.employee))
    {
      return false;
    }
    return true;
  }

  @Override
  public int compareTo(UserAccount o)
  {
    return this.employee.compareTo(o.employee);
  }

}
