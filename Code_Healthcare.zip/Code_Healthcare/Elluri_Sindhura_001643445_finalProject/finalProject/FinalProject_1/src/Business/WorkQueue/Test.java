//*************************************************//
//          //
//*************************************************//
package Business.WorkQueue;

import Business.Patient.PatientRecord;

/**
 *
 * @since Apr 21, 2016
 * @author Sindhura Elluri
 */
public abstract class Test extends WorkRequest
{

  private static long count = 0L;
  private final Long id = count++;
  private final PatientRecord patient;
  private boolean complete;
  private String comment;

  public Test(PatientRecord patient)
  {
    this.patient = patient;
  }

  public PatientRecord getPatient()
  {
    return patient;
  }

  public boolean isComplete()
  {
    return complete;
  }

  public void setComplete(boolean complete)
  {
    this.complete = complete;
  }

  public Long getId()
  {
    return id;
  }

  public String getComment()
  {
    return comment;
  }

  public void setComment(String comment)
  {
    this.comment = comment;
  }

  public abstract String getType();

}
