//*************************************************//
//          //
//*************************************************//
package Business.WorkQueue;

import Business.Patient.PatientRecord;

/**
 *
 * @since Apr 21, 2016
 * @author Sindhura Elluri
 */
public class BloodTestRequest extends Test
{

  public BloodTestRequest(PatientRecord patient)
  {
    super(patient);
  }

  @Override
  public String getType()
  {
    return "Blood";
  }

}
