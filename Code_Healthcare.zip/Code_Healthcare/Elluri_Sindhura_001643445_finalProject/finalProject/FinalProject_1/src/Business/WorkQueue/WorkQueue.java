/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import java.util.ArrayList;

/**
 *
 * @author Sindhura Elluri
 */
public class WorkQueue<T extends WorkRequest>
{

  private ArrayList<T> workRequestList;

  public WorkQueue()
  {
    workRequestList = new ArrayList<>();
  }

  public ArrayList<T> getWorkRequestList()
  {
    return workRequestList;
  }
}
