//*************************************************//
//          //
//*************************************************//
package Business.WorkQueue;

import Business.Incident.Incident;
import Business.UserAccount.UserAccount;

/**
 *
 * @since Apr 20, 2016
 * @author Sindhura Elluri
 */
public class CostAnalysisRequest extends WorkRequest
{

  private boolean approved;
  private boolean complete;
  private boolean sent;
  private String securityThreat;
  private String notFixedImplication;
  private String fixCost;
  private final Incident incident;

  public CostAnalysisRequest(Incident incident)
  {
    this.incident = incident;
  }

  public CostAnalysisRequest(Incident incident, String securityThreat, String notFixedImplication, String fixCost, UserAccount sender)
  {
    this(incident);
    this.securityThreat = securityThreat;
    this.notFixedImplication = notFixedImplication;
    this.fixCost = fixCost;
    this.sender = sender;
    sent = true;
  }

  public String getSecurityThreat()
  {
    return securityThreat;
  }

  public String getNotFixedImplication()
  {
    return notFixedImplication;
  }

  public String getFixCost()
  {
    return fixCost;
  }

  public void setApproved(boolean approved)
  {
    this.approved = approved;
    this.complete = true;
  }

  public void setComplete(boolean complete)
  {
    this.complete = complete;
  }

  public void setSecurityThreat(String securityThreat)
  {
    this.securityThreat = securityThreat;
  }

  public void setNotFixedImplication(String notFixedImplication)
  {
    this.notFixedImplication = notFixedImplication;
  }

  public void setFixCost(String fixCost)
  {
    this.fixCost = fixCost;
  }

  public boolean isApproved()
  {
    return approved;
  }

  public boolean isComplete()
  {
    return complete;
  }

  public Incident getIncident()
  {
    return incident;
  }

  public void setSent(boolean sent)
  {
    this.sent = sent;
  }

  public boolean isSent()
  {
    return sent;
  }

}
