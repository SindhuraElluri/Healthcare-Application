//*************************************************//
//          //
//*************************************************//
package Business.WorkQueue;

import Business.Patient.PatientRecord;

/**
 *
 * @since Apr 21, 2016
 * @author Sindhura Elluri
 */
public class UrineTestRequest extends Test
{

  public UrineTestRequest(PatientRecord patient)
  {
    super(patient);
  }

  @Override
  public String getType()
  {
    return "Urine";
  }

}
