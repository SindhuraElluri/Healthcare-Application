/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface;

import Business.Business;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import java.awt.CardLayout;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Sindhura Elluri
 */
public abstract class BusinessJPanel extends JPanel
{

  protected static final SimpleDateFormat dateFormat = new SimpleDateFormat("MM.dd.yyyy");

  protected final JPanel userProcessContainer;
  protected final Business business;
  protected final UserAccount account;
  protected final Organization organization;

  public BusinessJPanel(JPanel userProcessContainer, Business business, UserAccount account, Organization organization)
  {
    this.userProcessContainer = userProcessContainer;
    this.business = business;
    this.account = account;
    this.organization = organization;
  }

  public String getId()
  {
    return this.getClass().getSimpleName();
  }

  public void back()
  {
    userProcessContainer.remove(this);
    CardLayout layout = (CardLayout) userProcessContainer.getLayout();
    layout.previous(userProcessContainer);
  }

  public void newWindow(BusinessJPanel newWindow)
  {
    userProcessContainer.add(getId(), newWindow);

    CardLayout layout = (CardLayout) userProcessContainer.getLayout();
    layout.next(userProcessContainer);
  }

  public void newWindow(ChartBusinessJPanel newWindow)
  {
    userProcessContainer.add(getId(), newWindow);

    CardLayout layout = (CardLayout) userProcessContainer.getLayout();
    layout.next(userProcessContainer);
  }

  public boolean validateTextField(JTextField textField, String errorMessage)
  {
    boolean isValid = !textField.getText().trim().isEmpty();
    if (!isValid)
    {
      showMessage(errorMessage);
    }
    return isValid;
  }

  public boolean validateObject(Object object, String errorMessage)
  {
    boolean isValid = object != null;
    if (!isValid)
    {
      showMessage(errorMessage);
    }
    return isValid;
  }

  public void showMessage(String message)
  {
    JOptionPane.showMessageDialog(this, message);
  }

}
